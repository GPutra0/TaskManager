import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import sqlite3 from 'sqlite3';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import cors from 'cors';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'fallback_secret';

app.use(cors());
app.use(express.json());

// Database Setup
const db = new sqlite3.Database('database.sqlite');

const run = (sql: string, params: any[] = []) => {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function (err) {
      if (err) reject(err);
      else resolve(this);
    });
  });
};

const get = (sql: string, params: any[] = []) => {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) reject(err);
      else resolve(row);
    });
  });
};

const all = (sql: string, params: any[] = []) => {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) reject(err);
      else resolve(rows);
    });
  });
};

async function initDb() {
  await run(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE,
      password TEXT
    )
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS tasks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT,
      description TEXT,
      status TEXT CHECK(status IN ('todo', 'in-progress', 'done')),
      due_date TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS activity_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      task_id INTEGER,
      action TEXT,
      details TEXT,
      timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(task_id) REFERENCES tasks(id)
    )
  `);

  // Create a default user if not exists
  const defaultUser = await get('SELECT * FROM users WHERE username = ?', ['admin']);
  if (!defaultUser) {
    const hashedPassword = await bcrypt.hash('admin123', 10);
    await run('INSERT INTO users (username, password) VALUES (?, ?)', ['admin', hashedPassword]);
    console.log('Default user created: admin / admin123');
  }
}

initDb().catch(console.error);

// Middleware
const authenticateToken = (req: any, res: any, next: any) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) return res.sendStatus(401);

  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
};

// Auth Routes
app.post('/api/auth/login', async (req, res) => {
  const { username, password } = req.body;
  const user: any = await get('SELECT * FROM users WHERE username = ?', [username]);

  if (user && await bcrypt.compare(password, user.password)) {
    const token = jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, { expiresIn: '24h' });
    res.json({ token });
  } else {
    res.status(401).json({ message: 'Invalid credentials' });
  }
});

// Task Routes
app.get('/api/tasks', authenticateToken, async (req, res) => {
  const tasks = await all('SELECT * FROM tasks ORDER BY created_at DESC');
  res.json(tasks);
});

app.post('/api/tasks', authenticateToken, async (req, res) => {
  const { title, description, status, due_date } = req.body;
  const result: any = await run(
    'INSERT INTO tasks (title, description, status, due_date) VALUES (?, ?, ?, ?)',
    [title, description, status || 'todo', due_date]
  );
  
  const taskId = result.lastID;
  await run('INSERT INTO activity_logs (task_id, action, details) VALUES (?, ?, ?)', [
    taskId,
    'CREATE',
    `Task "${title}" created`
  ]);

  res.status(201).json({ id: taskId });
});

app.put('/api/tasks/:id', authenticateToken, async (req, res) => {
  const { id } = req.params;
  const { title, description, status, due_date } = req.body;
  
  const oldTask: any = await get('SELECT * FROM tasks WHERE id = ?', [id]);
  if (!oldTask) return res.status(404).json({ message: 'Task not found' });

  await run(
    'UPDATE tasks SET title = ?, description = ?, status = ?, due_date = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
    [title, description, status, due_date, id]
  );

  let changes = [];
  if (oldTask.status !== status) changes.push(`status changed to ${status}`);
  if (oldTask.title !== title) changes.push(`title updated`);

  await run('INSERT INTO activity_logs (task_id, action, details) VALUES (?, ?, ?)', [
    id,
    'UPDATE',
    `Task updated: ${changes.join(', ') || 'no major changes'}`
  ]);

  res.json({ message: 'Task updated' });
});

app.get('/api/logs', authenticateToken, async (req, res) => {
  const logs = await all('SELECT * FROM activity_logs ORDER BY timestamp DESC LIMIT 50');
  res.json(logs);
});

// Vite integration
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
